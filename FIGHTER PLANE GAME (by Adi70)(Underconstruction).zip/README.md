A Fighter Plane Game where players control a fighter jet to battle enemy planes. Navigate through levels, shoot projectiles, and dodge enemy attacks. Stay vigilant as enemies increase in number and speed with each level. Collect power-ups, manage health, and strategize to achieve the highest level possible. Enjoy the adrenaline rush of aerial combat in this HTML5-based game!
Still Under Construction.
created by 'Adi7050'
